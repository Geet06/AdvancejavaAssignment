import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.*; 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class Dbassign {

	public static void main(String[] args) throws Exception {		
		{	
			Connection con=null;
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		    DocumentBuilder builder = factory.newDocumentBuilder();
		    Document doc = builder.newDocument();
		    Element results = doc.createElement("Results");
		    doc.appendChild(results);
			try {
				String username = "sql12274592";
				String password = "BYKrdA3mDn";
				String url = "jdbc:mysql://sql12.freemysqlhosting.net/sql12274592" ;
				
				Class.forName("com.mysql.cj.jdbc.Driver");
				con= DriverManager.getConnection(url, username, password);
				Statement stmt = con.createStatement();
		     	ResultSet rset = stmt.executeQuery("SELECT * FROM emp");
				ResultSetMetaData rsmd = rset.getMetaData();
				int colCount = rsmd.getColumnCount();
					
				 while (rset.next()) {
					     Element row = doc.createElement("Row");
					     row.appendChild(doc.createTextNode("Hello"));
					     results.appendChild(row);
			             for (int i = 1; i <= colCount; i++) {
			             String columnName = rsmd.getColumnName(i);
			             String s="Null";
			             
//			             Object value = rset.getObject(i);
//			             if(value!=null)
//			             {
//			            	 s=value.toString();
//			             }
			             
			            Element node = doc.createElement(columnName);			             
			             node.appendChild(doc.createTextNode(""+rset.getString(i)));
			             results.appendChild(node);
			             	}
		     }
		}
		     catch (Exception e) {
				e.printStackTrace();
			}
			  finally {
				      try { con.close(); }
				      catch (Exception ignore) {}
				    }
				    DOMSource domSource = new DOMSource(doc);
				    TransformerFactory tobj = TransformerFactory.newInstance();
				    Transformer transformer = tobj.newTransformer();
				    transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
				    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				    StreamResult sr = new StreamResult(new File("beforeinsert.xml"));
				    transformer.transform(domSource, sr);				    
	}

                    Insertingrow obj= new Insertingrow();
                    obj.insert();

		            DocumentBuilderFactory factory1 = DocumentBuilderFactory.newInstance();
        		    DocumentBuilder builder1 = factory1.newDocumentBuilder();
        		    Document doc1 = builder1.newDocument();
        		    Element results1 = doc1.createElement("Results");
        		    doc1.appendChild(results1);
        		    Connection con1=null;
                    try {
						String username = "sql12274592";
						String password = "BYKrdA3mDn";
						String url = "jdbc:mysql://sql12.freemysqlhosting.net/sql12274592" ;
						
						Class.forName("com.mysql.cj.jdbc.Driver");
						con1= DriverManager.getConnection(url, username, password);
						Statement stmt1 = con1.createStatement();
				     	ResultSet rset1 = stmt1.executeQuery("SELECT * FROM emp");
						ResultSetMetaData rsmd1 = rset1.getMetaData();
						int colCount = rsmd1.getColumnCount();		
							while (rset1.next()) {
							     Element row = doc1.createElement("Row");
							     row.appendChild(doc1.createTextNode("Hello"));
							     results1.appendChild(row);
					             for (int i = 1; i <= colCount; i++) {
					             String columnName = rsmd1.getColumnName(i);
//					             Object value = rset1.getObject(i);
//					             String s="NULL";
//					             if(value!=null)
//					             {
//					            	 s=value.toString();
//					             }
					             Element node = doc1.createElement(columnName);
				                 node.appendChild(doc1.createTextNode(""+rset1.getString(i)));
					             results1.appendChild(node);
					             	}
				          }
				}
				     catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}					
						    finally {
						      try { con1.close();
						      	}
						      catch (Exception ignore) {
						    	  
						      }
						    }

						    DOMSource domSource1 = new DOMSource(doc1);
						    TransformerFactory tobj1 = TransformerFactory.newInstance();
						    Transformer transformer1 = tobj1.newTransformer();
						    transformer1.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
                            transformer1.setOutputProperty(OutputKeys.INDENT, "yes");
						    StringWriter mysw1 = new StringWriter();
						    StreamResult sr1 = new StreamResult(new File("afterinsert.xml"));
						    transformer1.transform(domSource1, sr1);	
						    
						    Compare comp1=new Compare();
							comp1.compare();
		}

}
	

			
			
			
	

			
			

