

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Compare {
	
public void  compare() throws Exception  {
	
	BufferedReader FirstXML = new BufferedReader(new FileReader(new File("beforeinsert.xml")));
	BufferedReader secondXML = new BufferedReader(new FileReader(new File("afterinsert.xml")));
	String first = FirstXML.readLine();
	String second = secondXML.readLine();
    
	while(first!=null&&second!=null)
	{
		if(first.equals(second))
		{
			first=FirstXML.readLine();
			second=secondXML.readLine();
		}
		else
		{
			System.out.println(second);
			second=secondXML.readLine();
   		}
	}	
  }
}
