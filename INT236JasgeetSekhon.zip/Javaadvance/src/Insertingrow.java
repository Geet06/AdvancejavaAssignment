import java.sql.*;

public class Insertingrow {
	public void insert() {

		Statement stmt = null;
		ResultSet rs;
		Connection con = null;
		try {

			try {
//				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://sql12.freemysqlhosting.net/sql12274592", "sql12274592", "BYKrdA3mDn");
			} catch (Exception e) {
				System.out.println(e);
				System.exit(0);
			}
			String query = "INSERT INTO emp " + "VALUES(33644,'Sonali','HR',23,'2019-10-10',2,2,20)";
			System.out.println(query);
			stmt = con.prepareStatement(query);

			stmt.executeUpdate(query);

		} catch (Exception se) {
			se.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					con.close();
			} catch (SQLException se) {
			}
			try {
				if (con != null)
					con.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
			
		}
	}

}
